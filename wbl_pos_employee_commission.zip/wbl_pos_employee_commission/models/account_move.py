# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

from odoo import models

class AccountMove(models.Model):
    _inherit = 'account.move'

    def write(self, vals):
        res = super(AccountMove, self).write(vals)
        for invoice in self:
            if invoice.payment_state == 'paid':
                payout = self.env['commission.payout'].search([
                    ('commission_payout_invoice_button', '=', invoice.id),
                    ('status', '!=', 'paid')
                ], limit=1)
                if payout:
                    payout.mark_as_paid()
        return res
