from odoo import models

class AccountMove(models.Model):
    _inherit = 'account.move'

    def write(self, vals):
        res = super(AccountMove, self).write(vals)

        for invoice in self:
            if invoice.payment_state == 'paid':
                payout = self.env['commission.payout'].search([
                    ('commission_payout_invoice_button', '=', invoice.id),
                    ('status', '!=', 'paid')
                ], limit=1)
                if payout:
                    payout.mark_as_paid()
        return res
