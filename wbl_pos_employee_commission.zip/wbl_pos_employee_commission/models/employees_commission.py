from odoo import api, fields, models, _
from odoo.tools import formatLang
import logging
_logger = logging.getLogger(__name__)

class EmployeeCommission(models.Model):
    _name = 'employees.commission'
    _description = 'Employee Commission Data'
    _inherit = ['pos.load.mixin']

    name = fields.Char(string="Reference")
    date = fields.Datetime(string='Date')
    employee_name = fields.Many2one(comodel_name='res.users', string='Employee')
    order_reference_num = fields.Many2one('pos.order', string='Order Ref')
    session_reference_num = fields.Many2one('pos.session', string='Session')
    pos_order_name = fields.Char(string='Order Ref') # For Show on Screen
    pos_session_name = fields.Char(string='Session')   # For Show on Screen
    commission_amount = fields.Monetary(string='Commission Amount', currency_field='currency_id')  # custome
    commission_type = fields.Char(string='Com. Type')

    #Field for Add ('+' and '-') Sing in commission_amount fields
    commission_amount_with_sign = fields.Char(string='Commission Amount', compute='_compute_commission_amount_with_sign')

    # Add $ Sing in Con
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.company.currency_id)
    total_commission_login_user = fields.Float(compute='_compute_total_commission_login_user', store=True)

    @api.model
    def _load_pos_data_fields(self, config_id):
        return ['name', 'date', 'employee_name', 'order_reference_num', 'session_reference_num',
                'commission_amount', 'total_commission_login_user', 'pos_order_name', 'pos_session_name', 'commission_type']

    # Fun to commission Amount print with Currency_id and -,+, Sing.

    @api.depends('commission_amount', 'commission_type')
    def _compute_commission_amount_with_sign(self):
        for rec in self:
            sign = '+' if rec.commission_type == 'Credit' else '-'
            amount_str = formatLang(self.env, rec.commission_amount, currency_obj=rec.currency_id)
            rec.commission_amount_with_sign = f"{sign} {amount_str}"


    # THis fun used for print current login user commission (Used in for Frontend Data)

    # @api.depends('commission_amount')
    @api.depends('employee_name')
    def _compute_total_commission_login_user(self):
        for record in self:
            user_id = self.env.uid
            commissions = self.env['employees.commission'].search([
                ('employee_name', '=', user_id)
            ])
            total_commission = sum(comm.commission_amount for comm in commissions)
            record.total_commission_login_user = total_commission

    # Function  For SAVE total Commission in DB (Create and Write)

    @api.model
    def create(self, vals):
        record = super().create(vals)
        record._update_total_commission_for_user(record.employee_name.id)
        return record

    def write(self, vals):
        res = super().write(vals)
        if 'employee_name' in vals or 'commission_amount' in vals:
            for rec in self:
                rec._update_total_commission_for_user(rec.employee_name.id)
        return res

    def _update_total_commission_for_user(self, user_id):
        commissions = self.search([('employee_name', '=', user_id)])
        total = sum(c.commission_amount for c in commissions)
        commissions.write({'total_commission_login_user': total})

    @api.model
    def get_user_total_commission(self):
        user_id = self.env.user.id
        commissions = self.search([('employee_name', '=', user_id)])
        return sum(c.commission_amount for c in commissions)


    # <<<<<=========== Order Details Print in Form View
    order_lines = fields.One2many('pos.order.line', 'order_id', string='Order Lines', compute='_compute_order_lines', store=False)

    @api.depends('order_reference_num')
    def _compute_order_lines(self):
        for rec in self:
            rec.order_lines = self.env['pos.order.line'].search([('order_id', '=', rec.order_reference_num.id)])

    @api.model
    def get_user_available_commission(self):
        user_id = self.env.user.id

        # Get total earned commission
        commissions = self.search([('employee_name', '=', user_id), ('commission_type', '=', 'Credit')])
        total_commission = sum(c.commission_amount for c in commissions)

        # Get total withdrawn commission
        payouts = self.env['commission.payout'].search([
            ('payout_employee_name', '=', user_id),
            ('status', 'in', ['approve'])
        ])
        total_withdrawn = sum(p.req_amount for p in payouts)
        # Return net available commission
        return total_commission - total_withdrawn




class PosOrder(models.Model):
    _inherit = 'pos.order'

    @api.model
    def create(self, vals_list):
        orders = super().create(vals_list)

        for order in orders:
            commission_amount = self._calculate_commission(order)

            if commission_amount > 0:
                # ✅ Create commission record
                commission = self.env['employees.commission'].create({
                    'name': f'COM-CR-{order.id}',
                    'date': order.date_order,
                    'employee_name': order.user_id.id,
                    'order_reference_num': order.id,
                    'session_reference_num': order.session_id.id,
                    'pos_order_name': order.name,
                    'pos_session_name': order.session_id.name,
                    'commission_amount': commission_amount,
                    'commission_type': "Credit"
                })
                # Mail Send Code
                template = self.env.ref('wbl_pos_employee_commission.mail_template_commission_credit_sent', raise_if_not_found=False)
                if template:
                    try:
                        user_email = order.user_id.email or order.user_id.partner_id.email
                        admin_email = order.user_id.email
                        if user_email and admin_email:
                            email_values = {
                                'email_to': user_email,
                                'email_from': admin_email,  # Sender is the admin
                            }
                            # Send Mail
                            template.sudo().send_mail(commission.id, force_send=True, email_values=email_values)
                        else:
                            _logger.warning("User or admin email is missing. Email not sent.")
                    except Exception as e:
                        print(e)
                else:
                    _logger.warning("❌ Email template not found.")
        return orders

#<<<<<======== Calculate Commission based on rules True Condition

    def _calculate_commission(self, order):
        Rule = self.env['pos.commission.rule']
        Config = self.env['ir.config_parameter'].sudo()

        # Get only rules selected in config settings
        selected_rule_ids_str = Config.get_param('res.config.settings.pos_commission_setting', default='')
        selected_rule_ids = [int(rid) for rid in selected_rule_ids_str.split(',') if rid]
        applicable_rules = Rule.search([
            ('is_published', '=', True),
            ('id', 'in', selected_rule_ids),
            ('targeted_employee', 'in', order.user_id.id)
        ])

        commission_amount = 0  # initiAL/ Default  value

        for rule in applicable_rules:
            # ✅ First, check order amount is within range
            if order.amount_total > rule.minimum_sale_threshold and order.amount_total <= rule.minimax_order_amount:

                #  Check if customer matches, if customer is specified
                if rule.target_customer and order.partner_id not in rule.target_customer:
                    print(
                        f"Condition failed: Customer {order.partner_id.name} does not match the target customer for rule {rule.name}")
                    continue

                #  If specific products are required, ensure at least one is in the order
                if rule.specific_product:
                    has_specific_product = order.lines.filtered(lambda line: line.product_id in rule.specific_product)
                    if not has_specific_product:
                        print(f"Condition failed: No specific products found in order for rule {rule.name}")
                        continue  # Skip this rule

                # Calculate commission on full order total amount
                if rule.commission_type == 'fixed':
                    commission_amount = rule.fixed_amount
                elif rule.commission_type == 'percentage':
                    commission_amount = float(order.amount_total * rule.percentage_amount)

            else:
                print(f"Condition failed: Order total does not meet the threshold for rule {rule.name}")
                continue
        return commission_amount
