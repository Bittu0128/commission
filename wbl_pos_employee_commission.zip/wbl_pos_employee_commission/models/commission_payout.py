from odoo import api, fields, models
import logging

_logger = logging.getLogger(__name__)


class CommissionPayout(models.Model):
    _name = 'commission.payout'
    _description = 'Employee Commission Payout'
    _inherit = ['pos.load.mixin']

    name = fields.Char(string="Reference")
    payment_description = fields.Char(string="Description")
    payout_date = fields.Datetime(string='Date')
    payout_employee_name = fields.Many2one('res.users', string='Employee Name')
    req_amount = fields.Monetary(string="Requested Amount", currency_field='currency_id')
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.company.currency_id)
    commission_type_payout = fields.Char(string='Commission Type')

    status = fields.Selection([
        ('pending', 'Pending'),
        ('approve', 'Approve'),
        ('deny', 'Deny'),
    ], string='Status', default='pending', tracking=True)

    approve_button = fields.Boolean(compute='_compute_show_buttons', store=True)
    deny_button = fields.Boolean(compute='_compute_show_buttons', store=True)

    invoice_button = fields.Many2one(comodel_name='account.move', string='invoice')
    commission_payout_invoice_button = fields.Many2one(comodel_name='account.move', string='invoice')

    def action_view_invoices_create(self):
        partner = self.payout_employee_name.partner_id
        if not partner:
            raise UserError("No partner linked to employee!")

        # Use your custom product from XML ID
        product = self.env.ref('wbl_pos_employee_commission.payout_commission_product')  # <-- mY XML PRODCT tEMPLT

        # Create invoice with your product
        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': partner.id,
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': [(0, 0, {
                'product_id': product.id,
                'name': 'Commission Payout',
                'quantity': 1,
                'price_unit': self.req_amount or 0.0,
            })],
        })

        if invoice.invoice_line_ids:
            invoice.action_post()

        return {
            'name': 'Customer Invoice',
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'form',
            'res_id': invoice.id,
            'target': 'current',
        }

    def action_view_com_payout_create(self):
        print("hello Commission Payout")
        return {
            'name': ('Customer Invoice'),
            'view_mode': 'form',
            'view_id': self.env.ref('account.view_move_form').id,
            'res_model': 'account.move',
            'context': "{'move_type':'out_invoice'}",
            'type': 'ir.actions.act_window',
        }

    # <<<<<<<<<<<<======== Load fields in pos model

    @api.model
    def _load_pos_data_fields(self, config_id):
        return ['payment_description', 'payout_date', 'payout_employee_name', 'status', 'name', 'req_amount',
                'approve_button', 'currency_id', 'deny_button', 'invoice_button', 'commission_payout_invoice_button','commission_type_payout']

    # <<<<<<===== Crate Entry in Backedn with condition
    @api.model
    def create_commission_payout_entry(self, PayoutDetails):
        user = self.env.user
        user_id = self.env.user.id
        req_amount = PayoutDetails.get('req_amount')

        # Commission total check
        commission_model = self.env['employees.commission']
        commissions = commission_model.search([('employee_name', '=', user_id)])
        current_total = sum(c.commission_amount for c in commissions)

        if req_amount > current_total:
            raise ValueError("Requested amount exceeds available commission.")

        # Create payout record
        payoutfielddata = self.create({
            'name': PayoutDetails.get('payment_ref_num'),
            'payout_date': fields.Datetime.now(),
            'payout_employee_name': user_id,
            'payment_description': PayoutDetails.get('payment_description'),
            'req_amount': req_amount,
            'status': PayoutDetails.get('status'),
            'commission_type_payout' : "Debit"
        })

        # Mail send User to Admin when payout request Send
        template_for_admin = self.env.ref('wbl_pos_employee_commission.mail_template_commission_payout_request_by_user',
                                          raise_if_not_found=False)
        if template_for_admin:
            try:
                user_email = user.email or user.partner_id.email
                admin_user = self.env.ref('base.user_admin', raise_if_not_found=False)
                admin_email = admin_user.email if admin_user else False

                if user_email and admin_email:
                    email_values = {
                        'email_to': admin_email,
                        'email_from': user_email,
                    }
                    template_for_admin.sudo().send_mail(payoutfielddata.id, force_send=True, email_values=email_values)
                else:
                    _logger.warning("❌ User or admin email is missing. Email not sent.")
            except Exception as e:
                _logger.error(f"❌ Error sending email: {e}")
        else:
            _logger.warning("❌ Email template not found.")

        # Subtract commission from total
        commissions.write({'total_commission_login_user': current_total - req_amount})

        # Mail Send User to User When User Request for Payout

        template_for_user = self.env.ref(
            'wbl_pos_employee_commission.mail_template_commission_payout_request_by_user_send_to_user',
            raise_if_not_found=False)
        if template_for_user:
            try:
                user_email = user.email or user.partner_id.email
                admin_user = self.env.ref('base.user_admin', raise_if_not_found=False)
                admin_email = admin_user.email if admin_user else False

                if user_email and admin_email:
                    email_values = {
                        'email_to': user_email,
                        'email_from': user_email,
                    }
                    template_for_user.sudo().send_mail(payoutfielddata.id, force_send=True, email_values=email_values)
                else:
                    _logger.warning("❌ User or admin email is missing. Email not sent.")
            except Exception as e:
                _logger.error(f"❌ Error sending email: {e}")
        else:
            _logger.warning("❌ Email template not found.")

        return {
            'status': 'success',
            'estimate_id': payoutfielddata.id,
            'message': 'Commission withdrawn successfully.',
        }


    # Entry Create in Employee_Commission Table when commission Payout Approved(This Fun Call in this fun[action_request_approve]).

    def _create_debit_commission_entry(self):
        for rec in self:
            # Avoid duplicate entries
            already_created = self.env['employees.commission'].search([
                ('commission_type', '=', 'Debit'),
                ('pos_order_name', '=', f'Payout-{rec.id}')
            ])
            if already_created:
                continue

            self.env['employees.commission'].create({
                'name': f'COM-DR-{rec.id}',
                'date': rec.payout_date or fields.Datetime.now(),
                'employee_name': rec.payout_employee_name.id,
                'order_reference_num': False,
                'session_reference_num': False,
                'pos_order_name': rec.name,
                'pos_session_name': '-',
                'commission_amount': rec.req_amount,
                'commission_type': "Debit",
            })

    @api.depends('status')
    def _compute_show_buttons(self):
        for rec in self:
            is_paid = rec.status == 'pending'
            rec.approve_button = is_paid
            rec.deny_button = is_paid

    def action_request_approve(self):
        for rec in self:
            rec.status = 'approve'

            # ✅ Create Debit Entry
            rec._create_debit_commission_entry()

            template = self.env.ref('wbl_pos_employee_commission.mail_template_commission_approved_by_admin',
                                    raise_if_not_found=False)
            if template:
                try:
                    user = rec.payout_employee_name
                    user_email = user.email or user.partner_id.email
                    admin_email = self.env.user.email

                    if user_email and admin_email:
                        email_values = {
                            'email_to': user_email,
                            'email_from': admin_email,
                        }
                        template.sudo().send_mail(rec.id, force_send=True, email_values=email_values)
                    else:
                        _logger.warning("User or admin email is missing. Email not sent.")
                except Exception as e:
                    _logger.error(f"❌ Error sending email: {e}")
            else:
                _logger.warning("❌ Email template not found.")

        return {
            'effect': {
                'fadeout': 'slow',
                'message': 'Approved successfully!',
                'type': 'rainbow_man'
            }
        }

    def action_request_deny(self):
        for rec in self:
            rec.status = 'deny'

            template = self.env.ref('wbl_pos_employee_commission.mail_template_commission_deny_by_admin',
                                    raise_if_not_found=False)
            if template:
                try:
                    user = rec.payout_employee_name
                    user_email = user.email or user.partner_id.email
                    admin_email = self.env.user.email

                    if user_email and admin_email:
                        email_values = {
                            'email_to': user_email,
                            'email_from': admin_email,
                        }
                        template.sudo().send_mail(rec.id, force_send=True, email_values=email_values)
                    else:
                        _logger.warning("User or admin email is missing. Email not sent.")
                except Exception as e:
                    _logger.error(f"❌ Error sending email: {e}")
            else:
                _logger.warning("❌ Email template not found.")

        return {
            'effect': {
                'fadeout': 'slow',
                'message': 'Denied successfully!',
                'type': 'rainbow_man'
            }
        }
