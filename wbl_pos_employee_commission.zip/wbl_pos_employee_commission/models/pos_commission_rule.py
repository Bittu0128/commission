# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

from odoo import models, fields, api

class PosCommissionRule(models.Model):
    _name = 'pos.commission.rule'
    _description = 'Pos Commission Rule'

    name = fields.Char(string='Rule', required=True)
    is_published = fields.Boolean(string='Published', default=False)
    specific_product = fields.Many2many("product.product", string='Specific Product', required=True)
    minimum_sale_threshold = fields.Monetary(string='Minimum Sale Threshold',  currency_field='currency_id')
    minimax_order_amount = fields.Monetary(string='Maximum Order Amount',  currency_field='currency_id')
    target_customer = fields.Many2many(comodel_name='res.partner', string='Target Customer')
    commission_type = fields.Selection([('fixed', 'Fixed'), ('percentage', 'Percentage')], string="Commission Type",
                                       required=True, default='fixed')
    fixed_amount = fields.Monetary(string="Fixed Commission",  currency_field='currency_id')
    percentage_amount = fields.Float(string="Percentage Commission")
    targeted_employee = fields.Many2many('res.users', string='Targeted Employee')
    currency_id = fields.Many2one('res.currency', string='Currency',default=lambda self: self.env.company.currency_id )

    # Control Published Button
    def action_toggle_is_published(self):
        for record in self:
            record.is_published = not record.is_published
