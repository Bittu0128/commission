# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

from odoo import api, models, fields

class ResConfigSettings(models.TransientModel):
    _inherit='res.config.settings'

    pos_commission_setting = fields.Many2many('pos.commission.rule', string="POS Commission Setting")
    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        IrConfigParam = self.env['ir.config_parameter'].sudo()

        pos_commission_setting_str = IrConfigParam.get_param('res.config.settings.pos_commission_setting', default='')
        pos_commission_setting = [int(uid) for uid in pos_commission_setting_str.split(',') if uid]
        res.update({
            'pos_commission_setting': [(6, 0, pos_commission_setting)],
        })
        return res

    def set_values(self):
        res = super(ResConfigSettings, self).set_values()
        IrConfigParam = self.env['ir.config_parameter'].sudo()

        pos_commission_setting_str = ','.join(map(str, self.pos_commission_setting.ids))
        IrConfigParam.set_param('res.config.settings.pos_commission_setting', pos_commission_setting_str)
        return res
