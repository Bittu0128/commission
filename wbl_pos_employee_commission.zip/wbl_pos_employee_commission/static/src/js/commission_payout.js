/** @odoo-module */

import { Dialog } from "@web/core/dialog/dialog";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { useState } from "@odoo/owl";
import { Component } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { _t } from "@web/core/l10n/translation";
import { rpc } from "@web/core/network/rpc";
import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";

export class CommissionPayout extends Component {
    static template = "wbl_employee_commission.CommissionPayout";
    static components = { Dialog };
    static props = {
        close: Function,
    };

    setup() {
        this.pos = usePos();
        this.dialogService = useService("dialog");
        this.dialog = useService("dialog");
        this.form = useState({
            payment_description: "",
            req_amount: "",
            cashable_amount: "",
        });
    }

    async createNewPayout() {
        const Requested_Amount = parseFloat(this.form.req_amount || 0);
        const Payment_Description = this.form.payment_description;
        const timestamp = String(Date.now()).slice(-5);

        const PayoutDetails = {
            payment_ref_num: `CP-${timestamp}`,
            payment_ref_num_int: parseInt(timestamp),
            payment_description: Payment_Description,
            req_amount: Requested_Amount,
            status: "pending",
        };

        try {
            const result = await rpc("/web/dataset/call_kw/commission.payout/create_commission_payout_entry", {
                model: "commission.payout",
                method: "create_commission_payout_entry",
                args: [PayoutDetails],
                kwargs: {},
            });

            const updated_commission = await rpc("/web/dataset/call_kw/employees.commission/get_user_available_commission", {
                model: "employees.commission",
                method: "get_user_available_commission",
                args: [],
                kwargs: {},
            });

            this.pos.commissionState.totalCommission = parseFloat(updated_commission || 0);
            this.dialog.add(AlertDialog, {
                title: _t("Request Submitted"),
                body: _t("Your commission withdrawal request was sent successfully."),
                });
            this.props.close();

        } catch (error) {
            this.dialog.add(AlertDialog, {
                title: _t("Invalid Amount"),
                body: _t("Entered amount exceeds your available commission. Please enter a valid amount."),
                });
            this.props.close();
        }
    }
}
