/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { Component, xml } from "@odoo/owl";
import { ControlButtons } from "@point_of_sale/app/screens/product_screen/control_buttons/control_buttons";
import {CommissionPayout}  from "./commission_payout";

patch(ControlButtons.prototype, {
    setup(){
        super.setup();
        this.pos = usePos();
        this.dialog = useService("dialog");
    },

    async payout_popup(){
        this.dialog.add(CommissionPayout);
    }
});