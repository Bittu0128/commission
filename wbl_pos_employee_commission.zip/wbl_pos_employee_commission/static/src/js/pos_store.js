/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { reactive } from "@odoo/owl";
import { rpc } from "@web/core/network/rpc";

patch(PosStore.prototype, {
    async processServerData() {
        await super.processServerData(...arguments);
        this.EmployeeCommission = this.data.models["employees.commission"];
        this.CommissionPayout = this.data.models["commission.payout"];

        // ✅ Backend se net commission fetch karo (earned - withdrawn)
        const netAvailableCommission = await rpc("/web/dataset/call_kw/employees.commission/get_user_available_commission", {
            model: "employees.commission",
            method: "get_user_available_commission",
            args: [],
            kwargs: {},
        });
        console.log(netAvailableCommission)

        // ✅ Commission state set karo
        this.commissionState = reactive({
            totalCommission: parseFloat(netAvailableCommission || 0).toFixed(2),
        });
        console.log(this.commissionState)
    },
});
