/** @odoo-module **/
import { registry } from "@web/core/registry";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { useService } from "@web/core/utils/hooks";
import { _t } from "@web/core/l10n/translation";
import { formatDateTime, parseDateTime } from "@web/core/l10n/dates";
import { patch } from "@web/core/utils/patch";
import { parseUTCString } from "@point_of_sale/utils";
import { Component, onMounted, onWillStart, useState, reactive, useEffect } from "@odoo/owl";



export class CommissionRecord extends Component {
    static template = "wbl_pos_employee_commission.CommissionRecord";
    static props = {};

       setup() {
            this.pos = usePos();
            this.state = useState({ commissions: [] });

            useEffect(() => {
                if (
                    this.pos.EmployeeCommission &&
                    this.pos.EmployeeCommission.getAll().length > 0
                ) {
                    const allCommissions = this.pos.EmployeeCommission.getAll();
                    const currentEmployeeId = this.pos.get_cashier().id;

                    this.state.commissions = allCommissions.filter(
                        (commission) => commission._raw.employee_name === currentEmployeeId
                    );
                }
//                console.log(this.state.commissions)
            });
       }

       get tablefooterCommissionAmount() {
        return this.state.commissions.reduce(
            (sum, c) => sum + (c.commission_amount || 0),
            0
        );
    }

}

registry.category("pos_screens").add("CommissionRecord", CommissionRecord);