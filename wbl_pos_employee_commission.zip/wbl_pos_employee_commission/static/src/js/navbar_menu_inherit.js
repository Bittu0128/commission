/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { patch } from "@web/core/utils/patch";
import { Component, xml } from "@odoo/owl";
import { Navbar } from "@point_of_sale/app/navbar/navbar";
import { CommissionRecord } from "./commission_record";

patch(Navbar.prototype, {
    setup(){
        super.setup();
        this.pos = usePos();
    },

    async goToCommissionRecord() {
            this.pos.showScreen("CommissionRecord");
    }

});
